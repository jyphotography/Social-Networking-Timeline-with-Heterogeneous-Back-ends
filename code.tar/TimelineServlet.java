package cc.cmu.edu.minisite;
/*
 * Author: Jason Yang
 * Course: Cloud Computing
 * Project: 3.4
 * Task: Connect 3 databases to a social website
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.sql.*;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HConnection;
import org.apache.hadoop.hbase.client.HConnectionManager;
import org.apache.hadoop.hbase.client.HTableInterface;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
public class TimelineServlet extends HttpServlet {
    //mysql
    private static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    private static final String DB_NAME = "test";
    private static final String URL = "jdbc:mysql://jdbc.coi82ndv3uzs.us-east-1.rds.amazonaws.com:3306/test";
    private static final String DB_USER = "jasony";
    private static final String DB_PWD = "15619root";
    private static java.sql.Connection conn2;
    //hbase
    private static String zkAddr = "172.31.22.69";
    private static String tableName = "result";
    private static String tableName2 = "result2";
    private static HTableInterface songsTable;
    private static HTableInterface followerTable;
    private static HConnection conn;
    private static HConnection conn3;
    private static byte[] bColFamily = Bytes.toBytes("data");
    private final static Logger logger = Logger.getRootLogger();
    //mongodb
    public DBCollection table;
    
    public TimelineServlet() throws Exception {
        //mysql
        initializeConnection();
        //hbase
        initializeConnection2();
        //mongodb
        MongoClient mongo = new MongoClient("ec2-54-210-194-93.compute-1.amazonaws.com", 27017);
        DB db = mongo.getDB("posts");
        table = db.getCollection("post");

    }

    @Override
    protected void doGet(final HttpServletRequest request,
            final HttpServletResponse response) throws ServletException, IOException {

        JSONObject result = new JSONObject();
        String id = request.getParameter("id");
        
        /*
            Task 4 (1):
            Get the name and profile of the user as you did in Task 1
            Put them as fields in the result JSON object
        */
        JSONObject info = new JSONObject();
        Statement stmt = null;       
        try {
            stmt = conn2.createStatement();

            String sql = "SELECT name, url FROM output WHERE id=" + id + ";";
            ResultSet rs = stmt.executeQuery(sql);

            if (rs.next()) {
                result.put("name", rs.getString("name"));
                result.put("profile", rs.getString("url"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } 
       

        /*
            Task 4 (2);
            Get the follower name and profiles as you did in Task 2
            Put them in the result JSON object as one array
        */
        JSONArray followers = new JSONArray();

        String followerlist = search(id);
        String[] frs = followerlist.split(" ");
//        System.out.println(Arrays.toString(frs));
        ArrayList<JSONObject> frlist = new ArrayList();
//        Statement stmt = null;
        for (String uid : frs) {
//            System.out.println(x);
            try {
                stmt = conn2.createStatement();
                String sql = "SELECT name, url FROM output WHERE id=" + uid +";";
                ResultSet rs = stmt.executeQuery(sql);
                if (rs.next()) {
                    JSONObject follower = new JSONObject();
                    follower.put("name", rs.getString("name"));
                    follower.put("profile", rs.getString("url"));
                    frlist.add(follower);
                }
                rs.close();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        // sort based on name and profile
        Collections.sort(frlist, new Comparator<JSONObject>() {
            @Override
            public int compare(JSONObject o1, JSONObject o2) {
                if (o1.get("name").equals(o2.get("name")))
                    return o1.get("profile").toString().compareTo(o2.get("profile").toString());
                else
                    return o1.get("name").toString().compareTo(o2.get("name").toString());
            }
        });

        // add into JSONArray
        for (JSONObject json : frlist) {
            followers.put(json);
        }
        if (frs.length == 0) {
            JSONObject follower = new JSONObject();
            follower.put("name", "Unauthorized");
            follower.put("profile", "#");
            followers.put(follower);
        }

        result.put("followers", followers);

        /*
            Task 4 (3):
            Get the 30 LATEST followee posts and put them in the
            result JSON object as one array.

            The posts should be sorted:
            First in ascending timestamp order
            Then numerically in ascending order by their PID (PostID) 
	    if there is a tie on timestamp
        */
        ArrayList<JSONObject> list = new ArrayList();

        JSONArray postResult = new JSONArray();
        String followeelist = searchPosts(id);
        String[] fes = followeelist.split(" ");
        System.out.println(Arrays.toString(fes));
        for (String uid : fes) {
            
            DBObject searchQuery = new BasicDBObject();
            searchQuery.put("uid", Integer.parseInt(uid));
            DBObject removeIdProjection = new BasicDBObject("_id", 0);
            DBCursor cursor = table.find(searchQuery, removeIdProjection);
//            cursor.sort(new BasicDBObject("timestamp", 1).append("pid", 1));

            while (cursor.hasNext()) {
                String s = String.format("%s",cursor.next());
                JSONObject post = new JSONObject(s);
                list.add(post);

            }

        }
        // sort by timestamp then by pid
        Collections.sort(list, new Comparator<JSONObject>() {
            @Override
            public int compare(JSONObject o1, JSONObject o2) {
                if (o1.get("timestamp").equals(o2.get("timestamp")))
                    return o1.get("pid").toString().compareTo(o2.get("pid").toString());
                else
                    return o1.get("timestamp").toString().compareTo(o2.get("timestamp").toString());
            }
        });
        // return only 30 result
        if (list.size()<= 30) {
            for (int i = 0;  i < list.size(); i++) {
                postResult.put(list.get(i));
            }
        } else {
            for (int i = list.size() - 30 ;  i < list.size(); i++) {
                postResult.put(list.get(i));
            }
        } 
        result.put("posts", postResult);
    
        PrintWriter out = response.getWriter();
        out.print(String.format("returnRes(%s)", result.toString()));
        out.close();
    }

    @Override
    protected void doPost(final HttpServletRequest req, final HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
    
    
    
    
    /**
     * Initialize HBase connection.
     * @throws IOException
     */
    static void initializeConnection2() throws IOException {
        // Remember to set correct log level to avoid unnecessary output.
        logger.setLevel(Level.ERROR);
        Configuration conf = HBaseConfiguration.create();
        conf.set("hbase.master", zkAddr + ":60000");
        conf.set("hbase.zookeeper.quorum", zkAddr);
        conf.set("hbase.zookeeper.property.clientport", "2181");
        if (!zkAddr.matches("\\d+.\\d+.\\d+.\\d+")) {
            System.out.print("HBase not configured!");
            return;
        }
        conn = HConnectionManager.createConnection(conf);           
        songsTable = conn.getTable(Bytes.toBytes(tableName));
        
        followerTable = conn.getTable(Bytes.toBytes(tableName2));
        System.out.println("HBase set up");
            
    }
    /**
     * Initializes mysql database connection.
     *
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    private static void initializeConnection() throws ClassNotFoundException, SQLException {
        Class.forName(JDBC_DRIVER);
        conn2 = DriverManager.getConnection(URL, DB_USER, DB_PWD);
        System.out.println("Intilize db connection");
    }
    
    // return followerlist based on id
    static String search(String id) throws IOException {
        // Instantiating Get class
        Get g = new Get(Bytes.toBytes(id));
        // Reading the data
        Result result = songsTable.get(g);
        // Reading values from Result class object
        byte [] value = result.getValue(Bytes.toBytes("data"),Bytes.toBytes("info"));
        // Printing the values
        String res = Bytes.toString(value).trim();
        return res;
    }
    
    // return followeelist based on id
    static String searchPosts(String id) throws IOException {
        // Instantiating Get class
        Get g = new Get(Bytes.toBytes(id));
        // Reading the data
        Result result = followerTable.get(g);
        // Reading values from Result class object
        byte [] value = result.getValue(Bytes.toBytes("data"),Bytes.toBytes("info"));
        // Printing the values
        String res = Bytes.toString(value).trim();
        return res;
    }
    
    
}

