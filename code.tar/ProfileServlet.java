package cc.cmu.edu.minisite;

/*
 * Author: Jason Yang
 * Course: Cloud Computing
 * Project: 3.4
 * Task: connect to mysql database to get user name and profile image url
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;
import java.sql.*;


public class ProfileServlet extends HttpServlet {

    private static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    private static final String URL = "jdbc:mysql://jdbc.coi82ndv3uzs.us-east-1.rds.amazonaws.com:3306/test";
    private static final String DB_USER = "jasony";
    private static final String DB_PWD = "15619root";
    private static java.sql.Connection conn;

    public ProfileServlet() throws ClassNotFoundException, SQLException {
   
        initializeConnection();
    }

    @Override
    protected void doGet(final HttpServletRequest request, final HttpServletResponse response)
            throws ServletException, IOException {
        /*
         * Task 1: This query simulates the login process of a user, and tests
         * whether your backend system is functioning properly. Your web
         * application will receive a pair of UserID and Password, and you need
         * to check in your backend database to see if the UserID and Password
         * is a valid pair. You should construct your response accordingly:
         * 
         * If YES, send back the user's Name and Profile Image URL. If NOT, set
         * Name as "Unauthorized" and Profile Image URL as "#".
         */

        Statement stmt = null;
        String name = "Unauthorized";
        String url = "#";

        try {
            stmt = conn.createStatement();
            String id = request.getParameter("id");
            String pwd = request.getParameter("pwd");
            // get name and url based on id and password
            String sql = "SELECT name, url FROM output WHERE id=" + id + " AND pw='" + pwd + "';";
            ResultSet rs = stmt.executeQuery(sql);

            if (rs.next()) {
                name = rs.getString("name");
                url = rs.getString("url");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } 

        // put result into JSON format
        JSONObject follower = new JSONObject();
        follower.put("name", name);
        follower.put("profile", url);
        
        PrintWriter writer = response.getWriter();
        writer.write(String.format("returnRes(%s)", follower.toString()));
        writer.close();

    }

    @Override
    protected void doPost(final HttpServletRequest request, final HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    /**
     * Initializes database connection.
     *
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    private static void initializeConnection() throws ClassNotFoundException, SQLException {
        Class.forName(JDBC_DRIVER);
        conn = DriverManager.getConnection(URL, DB_USER, DB_PWD);
        // conn = DriverManager.getConnection(URL);
        System.out.println("Intilize db connection");
    }
}
