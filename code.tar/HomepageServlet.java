package cc.cmu.edu.minisite;

/*
 * Author: Jason Yang
 * Course: Cloud Computing
 * Project: 3.4
 * Task: connect to mongodb database to get user posts
 */
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

import org.json.JSONObject;
import org.json.JSONArray;

public class HomepageServlet extends HttpServlet {

    public DBCollection table;

    public HomepageServlet() {
        /**** Connect to MongoDB ****/
        // Since 2.10.0, uses MongoClient
        MongoClient mongo = new MongoClient("ec2-54-210-194-93.compute-1.amazonaws.com", 27017);
        /**** Get database ****/
        // if database doesn't exists, MongoDB will create it for you
        DB db = mongo.getDB("posts");
        /**** Get collection ****/
        // if collection doesn't exists, MongoDB will create it for you
        table = db.getCollection("post");
    }

    @Override
    protected void doGet(final HttpServletRequest request, final HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");
        JSONObject result = new JSONObject();
        JSONArray postResult = new JSONArray();

        DBObject searchQuery = new BasicDBObject();
        searchQuery.put("uid", Integer.parseInt(id));
        // remove first _id element
        DBObject removeIdProjection = new BasicDBObject("_id", 0);
        DBCursor cursor = table.find(searchQuery, removeIdProjection);
        // sort based on timestamp in ascending order
        cursor.sort(new BasicDBObject("timestamp", 1));

        while (cursor.hasNext()) {
            String s = String.format("%s", cursor.next());
            System.out.println(s);
            JSONObject post = new JSONObject(s);
            postResult.put(post);
        }
        result.put("posts", postResult);

        PrintWriter writer = response.getWriter();
        writer.write(String.format("returnRes(%s)", result.toString()));
        writer.close();
    }

    @Override
    protected void doPost(final HttpServletRequest request, final HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
