package cc.cmu.edu.minisite;

/*
 * Author: Jason Yang
 * Course: Cloud Computing
 * Project: 3.4
 * Task: write a simple recommendation system based on user connection
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HConnection;
import org.apache.hadoop.hbase.client.HConnectionManager;
import org.apache.hadoop.hbase.client.HTableInterface;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

public class RecommendationServlet extends HttpServlet {
    // mysql
    private static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    private static final String URL = "jdbc:mysql://jdbc.coi82ndv3uzs.us-east-1.rds.amazonaws.com:3306/test";
    private static final String DB_USER = "jasony";
    private static final String DB_PWD = "15619root";
    private static java.sql.Connection conn2;
    // hbase
    private static String zkAddr = "172.31.22.69";
    private static String tableName2 = "result2";
    private static HTableInterface followerTable;
    private static HConnection conn;
    private final static Logger logger = Logger.getRootLogger();

    public RecommendationServlet() throws Exception {
        // mysql
        initializeConnection();
        // hbase
        initializeConnection2();

    }

    protected void doGet(final HttpServletRequest request, final HttpServletResponse response)
            throws ServletException, IOException {
        /**
         * Bonus task:
         * 
         * Recommend at most 10 people to the given user with simple
         * collaborative filtering.
         * 
         * Store your results in the result object in the following JSON format:
         * recommendation: [ {name:<name_1>, profile:<profile_1>} {name:
         * <name_2>, profile:<profile_2>} {name:<name_3>, profile:<profile_3>}
         * ... {name:<name_10>, profile:<profile_10>} ]
         * 
         * Notice: make sure the input has no duplicate!
         */
        JSONObject result = new JSONObject();
        String id = request.getParameter("id");
        // get first level of followee
        String followeelist = searchPosts(id);
        String[] fes = followeelist.split(" ");

        // prevent user itself and first level in final result
        HashSet<String> hs = new HashSet<String>();
        for (String x : fes) {
            hs.add(x);
        }

        // store user into map and calculate appear times
        Map<String, Integer> hm = new HashMap<String, Integer>();
        for (String x : fes) {
            String followee2list = searchPosts(x);
            String[] fes2 = followee2list.split(" ");
            for (String y : fes2) {
                if (hm.containsKey(y)) {
                    hm.put(y, hm.get(y) + 1);
                } else {
                    hm.put(y, 1);
                }
            }
        }

        // sort hashmap
        List<Map.Entry<String, Integer>> list = new ArrayList<Map.Entry<String, Integer>>(hm.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
            public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2) {
                if (o2.getValue().equals(o1.getValue())) {
                    return Integer.parseInt(o1.getKey()) - Integer.parseInt(o2.getKey());
                } else {
                    return o2.getValue().compareTo(o1.getValue());
                }
            }
        });

        // put first 10 result
        JSONArray jlist = new JSONArray();
        int count = 0;
        for (Map.Entry<String, Integer> mapping : list) {
            if (count == 10) {
                break;
            }
            String key = mapping.getKey();
            if (hs.contains(key)) {
                continue;
            } else {
                System.out.println(mapping.getKey() + ":" + mapping.getValue());
                jlist.put(findJson(key));
                count++;
            }

        }

        result.put("recommendation", jlist);

        PrintWriter writer = response.getWriter();
        writer.write(String.format("returnRes(%s)", result.toString()));
        writer.close();

    }

    @Override
    protected void doPost(final HttpServletRequest request, final HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    /**
     * Initialize HBase connection.
     * 
     * @throws IOException
     */
    static void initializeConnection2() throws IOException {
        // Remember to set correct log level to avoid unnecessary output.
        logger.setLevel(Level.ERROR);
        Configuration conf = HBaseConfiguration.create();
        conf.set("hbase.master", zkAddr + ":60000");
        conf.set("hbase.zookeeper.quorum", zkAddr);
        conf.set("hbase.zookeeper.property.clientport", "2181");
        if (!zkAddr.matches("\\d+.\\d+.\\d+.\\d+")) {
            System.out.print("HBase not configured!");
            return;
        }
        conn = HConnectionManager.createConnection(conf);
        followerTable = conn.getTable(Bytes.toBytes(tableName2));
        System.out.println("HBase set up");

    }

    /**
     * Initializes mysql database connection.
     *
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    private static void initializeConnection() throws ClassNotFoundException, SQLException {
        Class.forName(JDBC_DRIVER);
        conn2 = DriverManager.getConnection(URL, DB_USER, DB_PWD);
        System.out.println("Intilize db connection");
    }

    // helper to get hbase followee result
    static String searchPosts(String id) throws IOException {
        // Instantiating Get class
        Get g = new Get(Bytes.toBytes(id));
        // Reading the data
        Result result = followerTable.get(g);
        // Reading values from Result class object
        byte[] value = result.getValue(Bytes.toBytes("data"), Bytes.toBytes("info"));
        // Printing the values
        String res = Bytes.toString(value).trim();
        return res;
    }

    /**
     * get name and profile based on id
     * 
     * @param id
     *            user id
     * @return json object of user and
     */
    static JSONObject findJson(String id) {
        JSONObject result = new JSONObject();
        Statement stmt = null;
        try {
            stmt = conn2.createStatement();

            String sql = "SELECT name, url FROM output WHERE id=" + id + ";";
            ResultSet rs = stmt.executeQuery(sql);

            if (rs.next()) {
                result.put("name", rs.getString("name"));
                result.put("profile", rs.getString("url"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return result;
    }

}
