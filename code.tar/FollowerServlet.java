package cc.cmu.edu.minisite;

/*
 * Author: Jason Yang
 * Course: Cloud Computing
 * Project: 3.4
 * Task: connect to hbase database and get followers info
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.mysql.jdbc.Connection;
import java.sql.*;
import org.json.JSONArray;
import org.json.JSONObject;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.hbase.client.HTableInterface;
import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.client.HConnection;
import org.apache.hadoop.hbase.client.HConnectionManager;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class FollowerServlet extends HttpServlet {

    private static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    private static final String URL = "jdbc:mysql://jdbc.coi82ndv3uzs.us-east-1.rds.amazonaws.com:3306/test";
    private static final String DB_USER = "jasony";
    private static final String DB_PWD = "15619root";
    private static java.sql.Connection conn2;

    private static String zkAddr = "172.31.22.69";
    private static String tableName = "result";
    private static HTableInterface songsTable;
    private static HConnection conn;
    private final static Logger logger = Logger.getRootLogger();

    public FollowerServlet() throws ClassNotFoundException, SQLException, IOException {
        initializeConnection();
        initializeConnection2();
    }

    @Override
    protected void doGet(final HttpServletRequest request, final HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");
        JSONObject result = new JSONObject();
        JSONArray followers = new JSONArray();

        String followerlist = search(id);
        String[] frs = followerlist.split(" ");
        ArrayList<JSONObject> frlist = new ArrayList<JSONObject>();
        // iterate all followers name and profile and store in an arraylist
        Statement stmt = null;
        for (String uid : frs) {
            System.out.println(uid);
            try {
                stmt = conn2.createStatement();
                String sql = "SELECT name, url FROM output WHERE id=" + uid + ";";
                ResultSet rs = stmt.executeQuery(sql);
                if (rs.next()) {
                    JSONObject follower = new JSONObject();
                    follower.put("name", rs.getString("name"));
                    follower.put("profile", rs.getString("url"));
                    frlist.add(follower);
                }
                rs.close();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        // sort based on name and profile
        Collections.sort(frlist, new Comparator<JSONObject>() {
            @Override
            public int compare(JSONObject o1, JSONObject o2) {
                if (o1.get("name").equals(o2.get("name")))
                    return o1.get("profile").toString().compareTo(o2.get("profile").toString());
                else
                    return o1.get("name").toString().compareTo(o2.get("name").toString());
            }
        });

        // add into JSONArray
        for (JSONObject json : frlist) {
            followers.put(json);
        }
        if (frs.length == 0) {
            JSONObject follower = new JSONObject();
            follower.put("name", "Unauthorized");
            follower.put("profile", "#");
            followers.put(follower);
        }

        result.put("followers", followers);

        PrintWriter writer = response.getWriter();
        writer.write(String.format("returnRes(%s)", result.toString()));
        writer.close();
    }

    @Override
    protected void doPost(final HttpServletRequest request, final HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    /**
     * Initialize HBase connection.
     * 
     * @throws IOException
     */
    static void initializeConnection2() throws IOException {
        // Remember to set correct log level to avoid unnecessary output.
        logger.setLevel(Level.ERROR);
        Configuration conf = HBaseConfiguration.create();
        conf.set("hbase.master", zkAddr + ":60000");
        conf.set("hbase.zookeeper.quorum", zkAddr);
        conf.set("hbase.zookeeper.property.clientport", "2181");
        if (!zkAddr.matches("\\d+.\\d+.\\d+.\\d+")) {
            System.out.print("HBase not configured!");
            return;
        }
        conn = HConnectionManager.createConnection(conf);
        songsTable = conn.getTable(Bytes.toBytes(tableName));
        System.out.println("HBase set up");

    }

    /**
     * Initializes mysql database connection.
     *
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    private static void initializeConnection() throws ClassNotFoundException, SQLException {
        Class.forName(JDBC_DRIVER);
        conn2 = DriverManager.getConnection(URL, DB_USER, DB_PWD);
        // conn = DriverManager.getConnection(URL);
        System.out.println("Intilize db connection");
    }

    static String search(String id) throws IOException {
        // Instantiating Get class
        Get g = new Get(Bytes.toBytes(id));
        // Reading the data
        Result result = songsTable.get(g);
        // Reading values from Result class object
        byte[] value = result.getValue(Bytes.toBytes("data"), Bytes.toBytes("info"));
        // Printing the values
        String res = Bytes.toString(value).trim();
        return res;
    }

}
